#' @keywords internal
#' @useDynLib compGeometeR
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
