library(testthat)
library(compGeometeR)

test_check("compGeometeR")
